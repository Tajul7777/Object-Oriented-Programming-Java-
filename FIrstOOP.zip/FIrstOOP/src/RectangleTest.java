/**
 * Created by swakkhar on 5/11/16.
 */
public class RectangleTest
{
    public static void main(String args[])
    {
        Rectangle myRectangle=new Rectangle();

        myRectangle.setWidth(5);
        myRectangle.setHeight(6);

        System.out.println(myRectangle);

    }
}


