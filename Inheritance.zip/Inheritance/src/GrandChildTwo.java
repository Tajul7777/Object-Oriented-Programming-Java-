/**
 * Created by swakkhar on 5/23/16.
 */
public class GrandChildTwo extends ChildTwo{
    public String name;
    public GrandChildTwo(String a,String b,String c)
    {
        super(a,b);
        this.name=c;
    }
}


