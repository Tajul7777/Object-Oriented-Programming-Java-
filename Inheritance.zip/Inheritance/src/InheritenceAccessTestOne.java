/**
 * Created by swakkhar on 5/23/16.
 */
public class InheritenceAccessTestOne {
    public static void main(String args[])
    {
        ChildOne child= new ChildOne();
        System.out.println(child.getDiff());
    }
}


