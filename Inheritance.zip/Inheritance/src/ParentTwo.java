/**
 * Created by swakkhar on 5/23/16.
 */
public class ParentTwo {
    public String name = "UIU";
}


