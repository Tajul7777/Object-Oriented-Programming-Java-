/**
 * Created by swakkhar on 5/14/16.
 */
public class Rectangle {
    public int width=5;
    public int height=4;

    public int getArea()
    {
        return width*height;
    }
}

