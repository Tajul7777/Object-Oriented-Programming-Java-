/**
 * Created by swakkhar on 5/23/16.
 */
public class SuperUseTwo {
    public static void main(String argsp[])
    {
        GrandChildTwo grandChild=new GrandChildTwo("UIU","CSE","Swakkhar");
        grandChild.printMe();
    }
}


