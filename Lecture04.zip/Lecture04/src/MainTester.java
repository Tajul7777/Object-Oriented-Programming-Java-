/**
 * Created by swakkhar on 6/1/16.
 */
public class MainTester {
    public static void main(String args[])
    {
        System.out.println(OddMain.main(args));
        AnotherMain.main(args);
    }
}


