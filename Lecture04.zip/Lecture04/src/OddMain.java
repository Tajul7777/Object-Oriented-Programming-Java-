/**
 * Created by swakkhar on 6/1/16.
 */
public class OddMain {
    public static int main(String args[])
    {
        return 5;
    }
}


