/**
 * Created by swakkhar on 5/23/16.
 */
public class PackUsageOne
{
    public static void main(String args[])
    {
        packone.packtwo.AccessObjectTwo anObject = new packone.packtwo.AccessObjectTwo();
        System.out.println("Calling a method:"+anObject.getMyVarPublic());
    }
}



