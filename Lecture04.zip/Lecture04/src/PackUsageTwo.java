import packone.packtwo.AccessObjectTwo;

/**
 * Created by swakkhar on 5/23/16.
 */
public class PackUsageTwo {
    public static void main(String args[])
    {
        AccessObjectTwo anObject = new AccessObjectTwo();
        System.out.println("Calling a method:"+anObject.getMyVarPublic());
    }
}



