/**
 * Created by swakkhar on 6/1/16.
 */
public class StaticBlockOutsideTest
{
    public static void main(String args[])
    {
        StaticBlockTest myBlock=new StaticBlockTest();
    }
}

