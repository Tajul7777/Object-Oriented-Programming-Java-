/**
 * Created by swakkhar on 5/23/16.
 */
public class StructLikeStack {
        public int [] elements=new int[100];
        public int size=0;

}


