/**
 * Created by swakkhar on 6/19/16.
 */
public class DivisionZeroExp {
    public static void main(String args[])
    {
        int a=9;
        int b=0;
        int c=a/b;
    }
}


